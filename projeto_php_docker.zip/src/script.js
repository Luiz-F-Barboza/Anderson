function digaOi() {
  document.getElementById("resposta").innerText = "Você clicou no botão! 👋";
}
