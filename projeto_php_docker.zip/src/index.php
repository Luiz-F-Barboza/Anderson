<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Projeto Simples</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light text-center mt-5">
  <div class="container">
    <h1 class="text-primary">Olá, mundo!</h1>
    <p>Esse é um projeto simples com PHP, Bootstrap e JavaScript dentro do Docker.</p>

    <button class="btn btn-success" onclick="digaOi()">Clique aqui</button>

    <p id="resposta" class="mt-3"></p>
  </div>

  <script src="script.js"></script>
</body>
</html>
